@echo off
setlocal EnableExtensions
cd /d "%~dp0"

title Store Inventory Management - Simple Installation

echo ================================================================
echo   Store Inventory Management - Simple Installation
 echo ================================================================
echo.

python --version >nul 2>&1
if errorlevel 1 (
  echo ERROR: Python is not installed or not on PATH.
  echo Please install Python 3.12+ and enable "Add Python to PATH".
  pause
  exit /b 1
)

echo Installing/checking required Python components...
echo.
python -m pip install --disable-pip-version-check --upgrade pyinstaller reportlab python-docx openpyxl requests pywin32 pymupdf pillow
if errorlevel 1 (
  echo.
  echo ERROR: pip could not install/check the required packages.
  echo Please close any Python/Store Inventory process and run this file again.
  pause
  exit /b 1
)

rem pywin32's postinstall script can return a non-zero code even when the
rem package is installed correctly. Do NOT treat that script's return code
rem as a package-installation failure. Verify the module instead.
echo.
echo Checking Windows printer support...
python -c "from reportlab.pdfgen import canvas; from reportlab.lib.pagesizes import A4; import reportlab; print('PDF engine: OK')"
if errorlevel 1 (
  echo Installing PDF engine...
  python -m pip install reportlab pillow
  if errorlevel 1 (
    echo ERROR: ReportLab could not be installed.
    pause
    exit /b 1
  )
) else (
  echo PDF engine: OK
)

python -c "import win32print; print('Windows printer support: OK')" >nul 2>&1
if errorlevel 1 (
  echo Initializing pywin32 printer support...
  python -m pywin32_postinstall -install >nul 2>&1
  python -c "import win32print" >nul 2>&1
  if errorlevel 1 (
    echo WARNING: pywin32 printer support could not be initialized.
    echo The main program can still be built, but Portable Printer may be unavailable.
  ) else (
    echo Windows printer support: OK
  )
) else (
  echo Windows printer support: OK
)

echo.
echo Checking application source syntax...
python -m py_compile store_inventory.py
if errorlevel 1 (
  echo.
echo ERROR: store_inventory.py has a Python syntax error. Build stopped.
  pause
  exit /b 1
)
echo Source syntax: OK

echo Building Store Inventory Management...
if exist build rmdir /s /q build
if exist dist rmdir /s /q dist

python -m PyInstaller --clean --onefile --noconsole --name "StoreInventoryManagement" --collect-all reportlab --collect-all PIL --collect-all fitz --hidden-import reportlab.pdfgen.canvas --hidden-import reportlab.lib.utils --hidden-import reportlab.pdfbase._fontdata --add-data "inventory_seed.csv;." --add-data "company_logo.png;." store_inventory.py
if errorlevel 1 (
  echo.
  echo ERROR: PyInstaller build failed.
  pause
  exit /b 1
)

if not exist "dist\StoreInventoryManagement.exe" (
  echo.
  echo ERROR: StoreInventoryManagement.exe was not created.
  pause
  exit /b 1
)

if not exist "Program" mkdir "Program"
copy /Y "dist\StoreInventoryManagement.exe" "Program\StoreInventoryManagement.exe" >nul
if errorlevel 1 (
  echo ERROR: Could not copy the EXE to Program folder.
  pause
  exit /b 1
)
if exist "firebase_database_url.txt" copy /Y "firebase_database_url.txt" "Program\firebase_database_url.txt" >nul
if exist "FIREBASE_RULES_URL_ONLY.json" copy /Y "FIREBASE_RULES_URL_ONLY.json" "Program\FIREBASE_RULES_URL_ONLY.json" >nul
if exist "update_config.json" copy /Y "update_config.json" "Program\update_config.json" >nul

rem Create Desktop and Start Menu shortcuts ONLY after a successful build/copy.
echo.
echo Creating shortcuts...
powershell -NoProfile -ExecutionPolicy Bypass -Command "$ws=New-Object -ComObject WScript.Shell; $target=(Join-Path (Get-Location) 'Program\StoreInventoryManagement.exe'); $desktop=[Environment]::GetFolderPath('Desktop'); $s=$ws.CreateShortcut((Join-Path $desktop 'Store Inventory Management.lnk')); $s.TargetPath=$target; $s.WorkingDirectory=(Split-Path $target); $s.Description='Store Inventory Management'; $s.Save(); $start=Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs'; $s2=$ws.CreateShortcut((Join-Path $start 'Store Inventory Management.lnk')); $s2.TargetPath=$target; $s2.WorkingDirectory=(Split-Path $target); $s2.Description='Store Inventory Management'; $s2.Save()"
if errorlevel 1 (
  echo WARNING: Shortcut creation failed. You can run Program\StoreInventoryManagement.exe directly.
) else (
  echo Desktop shortcut created successfully.
  echo Start Menu shortcut created successfully.
)

echo.
echo ================================================================
echo   INSTALLATION COMPLETE
 echo ================================================================
echo.
echo Program: %CD%\Program\StoreInventoryManagement.exe
echo.
echo The program was NOT started automatically.
echo Use the "Store Inventory Management" Desktop shortcut to start it.
echo.
echo No C-drive installation and no Control Panel installer are used.
echo ================================================================
pause
exit /b 0
