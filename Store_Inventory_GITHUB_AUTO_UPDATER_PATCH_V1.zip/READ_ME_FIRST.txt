STORE INVENTORY MANAGEMENT - V31 SIMPLE INSTALL

1. Extract this ZIP completely.
2. Double-click BUILD_AND_INSTALL.bat.
3. The script checks/installs the required Python packages.
4. A pywin32 post-install warning is NOT treated as a package failure; printer support is verified separately.
5. PyInstaller builds Program\StoreInventoryManagement.exe.
6. Desktop and Start Menu shortcuts are created ONLY after the EXE has been successfully built and copied.
7. The application is NOT launched automatically by the installer/build script.
8. No C:\ installation and no Control Panel installer are used.

PORTABLE PRINTER
The application includes direct Windows RAW ESC/POS printing support for compatible thermal/portable printers. A printer driver must already be installed in Windows; the application does not silently install a vendor-specific printer driver.
