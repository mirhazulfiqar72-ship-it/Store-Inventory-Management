@echo off
echo This will remove the PROGRAM only.
echo Your data, backups and reports in C:\StoreInventoryManagement\Data,
echo \Backups and \Reports will be KEPT untouched unless you choose to delete them too.
echo.
set /p CONFIRM="Type YES to remove the program: "
if /i not "%CONFIRM%"=="YES" goto :eof

rmdir /s /q "C:\StoreInventoryManagement\App"
del "%USERPROFILE%\Desktop\Store Inventory Management.lnk" 2>nul
del "%APPDATA%\Microsoft\Windows\Start Menu\Programs\Store Inventory Management.lnk" 2>nul

echo.
echo Program removed. Your data was left in C:\StoreInventoryManagement\Data
echo (and backups in C:\StoreInventoryManagement\Backups) in case you reinstall later.
pause
