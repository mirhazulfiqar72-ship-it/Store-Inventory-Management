import hashlib
import json
import os
import subprocess
import sys
import tempfile
import urllib.request
import urllib.error
from tkinter import messagebox

APP_VERSION = "1.0.0"
CONFIG_NAME = "update_config.json"


def _app_dir():
    if getattr(sys, "frozen", False):
        return os.path.dirname(os.path.abspath(sys.executable))
    return os.path.dirname(os.path.abspath(__file__))


def _version_tuple(value):
    parts = []
    for p in str(value).strip().lstrip("vV").split("."):
        digits = "".join(ch for ch in p if ch.isdigit())
        parts.append(int(digits or 0))
    while len(parts) < 4:
        parts.append(0)
    return tuple(parts[:4])


def _load_config():
    path = os.path.join(_app_dir(), CONFIG_NAME)
    if not os.path.exists(path):
        return {}
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def _download(url, destination):
    req = urllib.request.Request(url, headers={"User-Agent": "StoreInventoryManagement-Updater"})
    with urllib.request.urlopen(req, timeout=30) as response, open(destination, "wb") as out:
        while True:
            chunk = response.read(1024 * 1024)
            if not chunk:
                break
            out.write(chunk)


def _sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest().lower()


def _install_after_exit(new_exe, current_exe):
    app_dir = os.path.dirname(current_exe)
    script = os.path.join(app_dir, ".store_inventory_update.cmd")
    pid = os.getpid()
    script_text = f'''@echo off\nsetlocal\nset "NEW={new_exe}"\nset "OLD={current_exe}"\nset "PID={pid}"\n:wait\ntasklist /FI "PID eq %PID%" 2>nul | findstr /I "%PID%" >nul\nif not errorlevel 1 (\n  timeout /t 1 /nobreak >nul\n  goto wait\n)\ntimeout /t 1 /nobreak >nul\nmove /Y "%NEW%" "%OLD%" >nul 2>&1\nif not exist "%OLD%" goto fail\nstart "" "%OLD%"\ndel "%~f0"\nexit /b 0\n:fail\nstart "" "%OLD%"\ndel "%~f0"\nexit /b 1\n'''
    with open(script, "w", encoding="utf-8") as f:
        f.write(script_text)
    subprocess.Popen(["cmd.exe", "/c", script], creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))


def check_for_update(parent):
    if not getattr(sys, "frozen", False):
        return
    try:
        config = _load_config()
        manifest_url = str(config.get("manifest_url", "")).strip()
        if not manifest_url:
            return
        req = urllib.request.Request(manifest_url, headers={"User-Agent": "StoreInventoryManagement-Updater"})
        try:
            with urllib.request.urlopen(req, timeout=8) as response:
                manifest = json.loads(response.read().decode("utf-8"))
        except Exception:
            # No internet / unavailable manifest must never disturb normal app startup.
            return
        latest = str(manifest.get("version", "")).strip()
        download_url = str(manifest.get("url", "")).strip()
        expected_sha = str(manifest.get("sha256", "")).strip().lower()
        if not latest or not download_url or _version_tuple(latest) <= _version_tuple(APP_VERSION):
            return
        if not messagebox.askyesno(
            "Update Available",
            f"A new version ({latest}) of Store Inventory Management is available.\n\n"
            f"Current version: {APP_VERSION}\n\nDownload and install it now?",
            parent=parent,
        ):
            return
        current_exe = os.path.abspath(sys.executable)
        fd, new_exe = tempfile.mkstemp(prefix="StoreInventoryManagement_", suffix=".exe", dir=_app_dir())
        os.close(fd)
        try:
            _download(download_url, new_exe)
            if expected_sha and _sha256(new_exe) != expected_sha:
                raise RuntimeError("Downloaded update failed SHA-256 verification.")
            _install_after_exit(new_exe, current_exe)
            messagebox.showinfo("Update Ready", "The update has been downloaded. The program will close and restart with the new version.", parent=parent)
            parent.destroy()
        except Exception:
            try:
                os.remove(new_exe)
            except Exception:
                pass
            raise
    except Exception as e:
        messagebox.showerror("Update Error", f"The update could not be installed.\n\n{e}", parent=parent)
