@echo off
setlocal
cd /d "%~dp0"
echo ================================================================
echo   Store Inventory Management - Firebase URL Setup
echo ================================================================
echo.
echo This setup uses ONLY the Firebase Realtime Database URL.
echo No Firebase API key is entered or stored by the app.
echo.
set /p FIREBASE_URL=Paste your Firebase Realtime Database URL: 
if "%FIREBASE_URL%"=="" (
  echo No URL entered. Nothing changed.
  pause
  exit /b 1
)
echo %FIREBASE_URL%>firebase_database_url.txt
echo.
echo Firebase URL saved to:
echo %CD%\firebase_database_url.txt
echo.
echo You can now run BUILD_AND_INSTALL.bat to build/install the desktop app.
echo IMPORTANT: Configure Firebase Realtime Database Rules as described in READ_ME_FIRST.txt.
pause
